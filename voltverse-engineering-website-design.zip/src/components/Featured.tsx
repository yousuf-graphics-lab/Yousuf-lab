import { motion } from 'framer-motion';
import { Clock, ArrowRight, User } from 'lucide-react';

const featuredArticles = [
  {
    id: 1,
    category: 'Tutorial',
    categoryColor: 'text-green-400 bg-green-400/10 border-green-400/20',
    title: 'Designing High-Speed PCBs: A Practical Guide',
    excerpt: 'Learn the fundamentals of impedance control, signal integrity, and routing strategies for high-speed digital circuits.',
    author: 'Dr. Sarah Chen',
    readTime: '12 min read',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 2,
    category: 'Project',
    categoryColor: 'text-electric-blue bg-electric-blue/10 border-electric-blue/20',
    title: 'Building a Custom RISC-V Microcontroller',
    excerpt: 'Step-by-step documentation of an FPGA-based soft core implementation using Verilog and open-source toolchains.',
    author: 'James Wilson',
    readTime: '25 min read',
    image: 'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 3,
    category: 'Industry Insight',
    categoryColor: 'text-purple-400 bg-purple-400/10 border-purple-400/20',
    title: 'The Future of Wide Bandgap Semiconductors',
    excerpt: 'How Silicon Carbide (SiC) and Gallium Nitride (GaN) are revolutionizing power electronics and electric vehicle drivetrains.',
    author: 'Elena Rodriguez',
    readTime: '8 min read',
    image: 'https://images.unsplash.com/photo-1573164713988-8665fc963095?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
  }
];

const Featured = () => {
  return (
    <section className="py-24 bg-navy-900 relative" id="articles">
      <div className="container mx-auto px-6 md:px-12">
        <div className="mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 flex flex-col items-start">
            Featured Articles
            <span className="w-24 h-1 bg-electric-blue mt-2 rounded-full shadow-[0_0_10px_rgba(0,212,255,0.8)]"></span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredArticles.map((article, index) => (
            <motion.article 
              key={article.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="glass-card rounded-xl overflow-hidden flex flex-col group cursor-pointer h-full"
            >
              {/* Image Container */}
              <div className="relative h-56 overflow-hidden">
                <div className="absolute inset-0 bg-navy-800/20 group-hover:bg-transparent transition-colors z-10"></div>
                <img 
                  src={article.image} 
                  alt={article.title} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute top-4 left-4 z-20">
                  <span className={`px-3 py-1 text-xs font-semibold uppercase tracking-wider rounded border backdrop-blur-md ${article.categoryColor}`}>
                    {article.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6 flex flex-col flex-grow">
                <h3 className="text-xl font-bold mb-3 text-text-primary group-hover:text-electric-blue transition-colors line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-text-secondary text-sm mb-6 line-clamp-3 flex-grow">
                  {article.excerpt}
                </p>

                {/* Meta */}
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-surface-hover">
                  <div className="flex items-center gap-4 text-xs text-text-secondary font-medium">
                    <span className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-electric-blue" />
                      {article.author}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {article.readTime}
                    </span>
                  </div>
                </div>

                {/* Hidden Read More that appears on hover/is part of layout */}
                <div className="mt-4 flex items-center text-electric-cyan text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0 duration-300">
                  Read Article <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Featured;