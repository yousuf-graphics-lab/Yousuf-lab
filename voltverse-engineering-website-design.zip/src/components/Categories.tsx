import { motion } from 'framer-motion';
import { Cpu, Zap, Wifi, Layers, Grid, Wrench } from 'lucide-react';

const categories = [
  {
    name: 'Embedded Systems',
    description: 'Microcontrollers, RTOS, and firmware development',
    icon: <Cpu className="w-8 h-8" />,
    color: 'from-blue-500/20 to-cyan-500/20',
    borderColor: 'group-hover:border-cyan-500/50'
  },
  {
    name: 'Power Electronics',
    description: 'Inverters, converters, and motor drives',
    icon: <Zap className="w-8 h-8" />,
    color: 'from-yellow-500/20 to-orange-500/20',
    borderColor: 'group-hover:border-yellow-500/50'
  },
  {
    name: 'RF & Wireless',
    description: 'Antenna design, IoT protocols, and SDR',
    icon: <Wifi className="w-8 h-8" />,
    color: 'from-purple-500/20 to-pink-500/20',
    borderColor: 'group-hover:border-purple-500/50'
  },
  {
    name: 'PCB Design',
    description: 'Layout techniques, Altium, and KiCad guides',
    icon: <Layers className="w-8 h-8" />,
    color: 'from-green-500/20 to-emerald-500/20',
    borderColor: 'group-hover:border-green-500/50'
  },
  {
    name: 'Semiconductors',
    description: 'IC design, fabrication, and physics',
    icon: <Grid className="w-8 h-8" />,
    color: 'from-red-500/20 to-rose-500/20',
    borderColor: 'group-hover:border-red-500/50'
  },
  {
    name: 'DIY Projects',
    description: 'Hands-on builds for makers and hobbyists',
    icon: <Wrench className="w-8 h-8" />,
    color: 'from-gray-500/20 to-slate-500/20',
    borderColor: 'group-hover:border-gray-400/50'
  }
];

const Categories = () => {
  return (
    <section className="py-24 bg-[#081221]" id="resources">
      <div className="container mx-auto px-6 md:px-12">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Explore by Discipline</h2>
          <p className="text-text-secondary">Dive deep into specialized branches of electrical engineering with our curated technical content.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((cat, index) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className={`relative overflow-hidden rounded-xl bg-surface/40 border border-surface-hover p-8 cursor-pointer group transition-all duration-300 ${cat.borderColor}`}
            >
              {/* Hover Gradient Overlay */}
              <div className={`absolute inset-0 bg-gradient-to-br ${cat.color} opacity-0 group-hover:opacity-100 transition-opacity duration-500`}></div>
              
              <div className="relative z-10">
                <div className="mb-6 inline-flex items-center justify-center w-16 h-16 rounded-xl bg-surface border border-surface-hover text-text-primary group-hover:text-white group-hover:scale-110 transition-all duration-300 shadow-lg">
                  {cat.icon}
                </div>
                <h3 className="text-xl font-bold mb-2 text-text-primary group-hover:text-white transition-colors">
                  {cat.name}
                </h3>
                <p className="text-text-secondary text-sm group-hover:text-text-primary/80 transition-colors">
                  {cat.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Categories;