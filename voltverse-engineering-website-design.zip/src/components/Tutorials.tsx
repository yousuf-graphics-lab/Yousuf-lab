import { motion } from 'framer-motion';
import { ArrowRight, Wrench, ShieldAlert } from 'lucide-react';

const tutorials = [
  {
    id: 1,
    title: 'Build a Smart IoT Power Supply',
    description: 'A comprehensive step-by-step guide to designing a programmable bench power supply with Wi-Fi telemetry using an ESP32 and custom PCB layout.',
    takeaways: ['Buck-Boost Topology', 'ESP32 Firmware', 'KiCad Layout'],
    difficulty: 'Advanced',
    difficultyColor: 'text-red-400 border-red-400/30 bg-red-400/10',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80',
    reversed: false
  },
  {
    id: 2,
    title: 'Designing Your First Arduino Shield',
    description: 'Learn the basics of schematic capture and PCB layout by creating a custom motor driver shield for the Arduino Uno ecosystem.',
    takeaways: ['Schematic Capture', 'Motor Drivers', 'DRC Checks'],
    difficulty: 'Beginner',
    difficultyColor: 'text-green-400 border-green-400/30 bg-green-400/10',
    image: 'https://images.unsplash.com/photo-1555664424-778a1e5e1b48?auto=format&fit=crop&q=80',
    reversed: true
  }
];

const Tutorials = () => {
  return (
    <section className="py-24 bg-navy-900 border-t border-surface/50" id="tutorials">
      <div className="container mx-auto px-6 md:px-12">
        <div className="mb-20 text-center max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Recent Tutorials</h2>
          <p className="text-text-secondary">Step-by-step guides from schematic capture to final assembly.</p>
        </div>

        <div className="space-y-24">
          {tutorials.map((tutorial) => (
            <div key={tutorial.id} className={`flex flex-col gap-12 lg:items-center ${tutorial.reversed ? 'lg:flex-row-reverse' : 'lg:flex-row'}`}>
              
              {/* Image Side */}
              <motion.div 
                initial={{ opacity: 0, x: tutorial.reversed ? 50 : -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="w-full lg:w-1/2 relative group cursor-pointer"
              >
                <div className="absolute inset-0 bg-electric-blue/10 rounded-2xl -m-4 group-hover:m-0 transition-all duration-300 -z-10 blur-xl"></div>
                <div className="relative rounded-2xl overflow-hidden border border-surface-hover aspect-video">
                  <img 
                    src={tutorial.image} 
                    alt={tutorial.title} 
                    className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 filter grayscale-[30%] group-hover:grayscale-0"
                  />
                  {/* Schematic Overlay Effect */}
                  <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20 mix-blend-overlay pointer-events-none"></div>
                </div>
              </motion.div>

              {/* Content Side */}
              <motion.div 
                initial={{ opacity: 0, x: tutorial.reversed ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="w-full lg:w-1/2 space-y-6"
              >
                <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full border text-xs font-bold uppercase tracking-wider ${tutorial.difficultyColor}`}>
                  {tutorial.difficulty === 'Beginner' ? <Wrench className="w-3.5 h-3.5" /> : <ShieldAlert className="w-3.5 h-3.5" />}
                  {tutorial.difficulty}
                </div>

                <h3 className="text-3xl font-bold text-text-primary group-hover:text-electric-blue transition-colors">
                  {tutorial.title}
                </h3>
                
                <p className="text-text-secondary text-lg leading-relaxed">
                  {tutorial.description}
                </p>

                <div className="space-y-3 pt-4">
                  <h4 className="text-sm font-semibold text-text-primary uppercase tracking-wider">Key Takeaways:</h4>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {tutorial.takeaways.map((item, i) => (
                      <li key={i} className="flex items-center gap-2 text-text-secondary text-sm bg-surface/40 px-3 py-2 rounded-md border border-surface-hover">
                        <div className="w-1.5 h-1.5 rounded-full bg-electric-cyan"></div>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <button className="mt-6 flex items-center gap-2 text-electric-blue hover:text-electric-cyan font-bold transition-colors group">
                  View Full Tutorial 
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </motion.div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Tutorials;