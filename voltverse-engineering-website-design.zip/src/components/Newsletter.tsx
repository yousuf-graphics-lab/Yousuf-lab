import { motion } from 'framer-motion';
import { Mail, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

const Newsletter = () => {
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubscribed(true);
    setTimeout(() => setSubscribed(false), 5000);
  };

  return (
    <section className="py-24 bg-navy-900 relative overflow-hidden" id="about">
      {/* Background Gradients */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-1/2 left-0 w-full h-full bg-electric-blue/5 -translate-y-1/2 rounded-full blur-[100px]"></div>
      </div>

      <div className="container mx-auto px-6 md:px-12 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-surface/60 backdrop-blur-md border border-electric-blue/20 rounded-2xl p-8 md:p-16 flex flex-col items-center text-center shadow-[0_0_40px_rgba(0,212,255,0.05)]"
        >
          <div className="w-16 h-16 bg-electric-blue/10 rounded-full flex items-center justify-center mb-6 border border-electric-blue/30">
            <Mail className="w-8 h-8 text-electric-cyan" />
          </div>
          
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Stay Current with VoltVerse</h2>
          <p className="text-lg text-text-secondary mb-10 max-w-2xl">
            Get weekly insights, project files, and engineering resources delivered straight to your inbox.
          </p>

          <form onSubmit={handleSubmit} className="w-full max-w-md relative">
            <div className="flex flex-col sm:flex-row gap-4">
              <input 
                type="email" 
                placeholder="Enter your email address" 
                required
                className="w-full bg-navy-900 border border-surface-hover focus:border-electric-blue focus:ring-1 focus:ring-electric-blue outline-none rounded-lg px-6 py-4 text-text-primary placeholder:text-text-secondary transition-all"
              />
              <button 
                type="submit" 
                className="px-8 py-4 bg-electric-blue hover:bg-electric-cyan text-navy-900 font-bold rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
              >
                Subscribe
              </button>
            </div>
            
            {/* Success Animation */}
            {subscribed && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute -bottom-10 left-0 w-full text-electric-cyan flex items-center justify-center gap-2 text-sm font-medium"
              >
                <CheckCircle2 className="w-4 h-4" />
                Successfully subscribed to the circuit!
              </motion.div>
            )}
            
            <p className="text-xs text-text-secondary mt-4 flex items-center justify-center gap-1 opacity-70">
              No spam, unsubscribe anytime.
            </p>
          </form>
        </motion.div>
      </div>
    </section>
  );
};

export default Newsletter;