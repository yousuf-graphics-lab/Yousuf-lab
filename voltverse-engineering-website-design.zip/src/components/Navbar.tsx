import { useState, useEffect } from 'react';
import { Search, Moon, Cpu, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = ['Home', 'Articles', 'Tutorials', 'Projects', 'Resources', 'About'];

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer group">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-surface group-hover:bg-electric-blue/10 transition-colors border border-surface-hover group-hover:border-electric-blue/50">
            <Cpu className="text-electric-blue w-6 h-6 group-hover:text-electric-cyan transition-colors" />
          </div>
          <span className="font-display font-bold text-2xl tracking-widest text-text-primary group-hover:text-white transition-colors">
            VOLT<span className="text-electric-blue group-hover:text-electric-cyan">VERSE</span>
          </span>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a key={link} href={`#${link.toLowerCase()}`} className="text-sm font-medium text-text-secondary hover:text-electric-cyan transition-colors">
              {link}
            </a>
          ))}
        </nav>

        {/* Icons */}
        <div className="hidden md:flex items-center gap-5">
          <button className="text-text-secondary hover:text-electric-blue transition-colors group relative">
            <Search className="w-5 h-5" />
          </button>
          <button className="text-text-secondary hover:text-electric-blue transition-colors">
            <Moon className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile Menu Toggle */}
        <button 
          className="md:hidden text-text-secondary hover:text-white"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden absolute top-full left-0 right-0 bg-navy-800 border-b border-surface p-6 flex flex-col gap-4 shadow-xl"
          >
            {navLinks.map((link) => (
              <a 
                key={link} 
                href={`#${link.toLowerCase()}`} 
                className="text-lg font-medium text-text-primary hover:text-electric-blue transition-colors py-2 border-b border-surface last:border-0"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Navbar;