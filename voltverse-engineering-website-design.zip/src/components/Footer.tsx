import { Cpu, Github, Twitter, Linkedin, Youtube, ArrowUp } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050B14] pt-20 pb-10 border-t border-surface relative">
      <div className="container mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
          
          {/* Logo Column */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-surface border border-electric-blue/50">
                <Cpu className="text-electric-blue w-6 h-6" />
              </div>
              <span className="font-display font-bold text-2xl tracking-widest text-text-primary">
                VOLT<span className="text-electric-blue">VERSE</span>
              </span>
            </div>
            <p className="text-text-secondary leading-relaxed mb-6 max-w-sm">
              Engineering the Future, One Circuit at a Time. A premium publication for modern electrical engineers, makers, and students.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-surface/50 flex items-center justify-center text-text-secondary hover:text-electric-blue hover:bg-surface transition-all group border border-transparent hover:border-electric-blue/30">
                <Twitter className="w-5 h-5 group-hover:drop-shadow-[0_0_8px_rgba(0,212,255,0.8)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-surface/50 flex items-center justify-center text-text-secondary hover:text-electric-blue hover:bg-surface transition-all group border border-transparent hover:border-electric-blue/30">
                <Github className="w-5 h-5 group-hover:drop-shadow-[0_0_8px_rgba(0,212,255,0.8)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-surface/50 flex items-center justify-center text-text-secondary hover:text-electric-blue hover:bg-surface transition-all group border border-transparent hover:border-electric-blue/30">
                <Linkedin className="w-5 h-5 group-hover:drop-shadow-[0_0_8px_rgba(0,212,255,0.8)]" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-surface/50 flex items-center justify-center text-text-secondary hover:text-electric-blue hover:bg-surface transition-all group border border-transparent hover:border-electric-blue/30">
                <Youtube className="w-5 h-5 group-hover:drop-shadow-[0_0_8px_rgba(0,212,255,0.8)]" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-text-primary mb-6">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Home</a></li>
              <li><a href="#articles" className="text-text-secondary hover:text-electric-cyan transition-colors">Articles</a></li>
              <li><a href="#tutorials" className="text-text-secondary hover:text-electric-cyan transition-colors">Tutorials</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Projects</a></li>
              <li><a href="#about" className="text-text-secondary hover:text-electric-cyan transition-colors">About</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-lg font-bold text-text-primary mb-6">Categories</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Embedded Systems</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Power Electronics</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">PCB Design</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">RF & Wireless</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Semiconductors</a></li>
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-lg font-bold text-text-primary mb-6">Resources</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Component Library</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Datasheet Search</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Code Snippets</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Sponsorships</a></li>
              <li><a href="#" className="text-text-secondary hover:text-electric-cyan transition-colors">Write for Us</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-surface flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-text-secondary text-sm">
            &copy; {new Date().getFullYear()} VoltVerse. Built with <span className="text-electric-blue">React</span> & <span className="text-electric-cyan">Tailwind</span>.
          </p>
          
          <div className="flex items-center gap-6 text-sm text-text-secondary">
            <a href="#" className="hover:text-electric-cyan transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-electric-cyan transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>

      {/* Back to top button */}
      <motion.button 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 w-12 h-12 rounded-full bg-surface border border-surface-hover hover:border-electric-blue flex items-center justify-center text-text-primary hover:text-electric-cyan transition-colors shadow-lg z-50 group"
      >
        <ArrowUp className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
      </motion.button>
    </footer>
  );
};

export default Footer;