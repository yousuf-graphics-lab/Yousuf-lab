import { motion } from 'framer-motion';
import { ArrowRight, Zap, Cpu } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-24 overflow-hidden" id="home">
      {/* Background Layer */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-grid-pattern opacity-10" style={{ backgroundSize: '60px 60px' }}></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-electric-blue/20 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-electric-cyan/10 rounded-full blur-[150px]"></div>
      </div>

      <div className="container relative z-10 mx-auto px-6 md:px-12 grid lg:grid-cols-2 gap-12 items-center">
        
        {/* Text Content */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-surface/80 border border-electric-blue/30 text-electric-cyan text-sm font-mono mb-6">
            <Zap className="w-4 h-4" />
            <span>Powering Engineering Minds</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6">
            Engineering the Future,<br />
            <span className="text-gradient">One Circuit at a Time.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-text-secondary mb-8 leading-relaxed max-w-xl">
            In-depth tutorials, cutting-edge projects, and engineering insights for the modern electrical engineer.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="px-8 py-4 rounded-md bg-electric-blue hover:bg-electric-cyan text-navy-900 font-bold tracking-wide transition-all duration-300 shadow-[0_0_20px_rgba(0,212,255,0.4)] hover:shadow-[0_0_30px_rgba(0,255,198,0.6)] flex items-center justify-center gap-2 group">
              Explore Articles
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 rounded-md bg-transparent border border-surface-hover hover:border-electric-blue text-text-primary font-medium transition-all duration-300 hover:bg-surface flex items-center justify-center">
              Subscribe for Updates
            </button>
          </div>
        </motion.div>

        {/* Visual Element */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="relative hidden lg:flex items-center justify-center h-full"
        >
          <div className="relative w-full aspect-square max-w-lg">
            {/* Abstract 3D/Glowing Representation using Framer Motion & CSS */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 rounded-full border border-surface-hover border-dashed opacity-50"
            ></motion.div>
            <motion.div 
              animate={{ rotate: -360 }}
              transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
              className="absolute inset-8 rounded-full border border-electric-blue/20"
            ></motion.div>
            
            {/* Center Glowing Element */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative w-48 h-48 bg-surface rounded-xl border border-electric-blue/30 shadow-[0_0_50px_rgba(0,212,255,0.2)] flex items-center justify-center animate-pulse-slow rotate-45 group hover:border-electric-cyan/50 transition-colors duration-500">
                <div className="-rotate-45">
                  <Cpu className="w-20 h-20 text-electric-blue group-hover:text-electric-cyan transition-colors duration-500 drop-shadow-[0_0_15px_rgba(0,212,255,0.8)]" />
                </div>
                {/* Circuit Traces */}
                <div className="absolute top-1/2 -right-8 w-8 h-px bg-electric-cyan/50"></div>
                <div className="absolute top-1/2 -left-8 w-8 h-px bg-electric-cyan/50"></div>
                <div className="absolute -top-8 left-1/2 w-px h-8 bg-electric-cyan/50"></div>
                <div className="absolute -bottom-8 left-1/2 w-px h-8 bg-electric-cyan/50"></div>
              </div>
            </div>
            
            {/* Floating particles */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full bg-electric-cyan shadow-[0_0_10px_rgba(0,255,198,0.8)]"
                animate={{
                  y: [0, Math.random() * -50 - 20, 0],
                  x: [0, Math.random() * 50 - 25, 0],
                  opacity: [0, 1, 0]
                }}
                transition={{
                  duration: 3 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 2
                }}
                style={{
                  top: `${20 + Math.random() * 60}%`,
                  left: `${20 + Math.random() * 60}%`
                }}
              />
            ))}
          </div>
        </motion.div>

      </div>
    </section>
  );
};

export default Hero;