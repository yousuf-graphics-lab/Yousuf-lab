import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Featured from './components/Featured';
import Categories from './components/Categories';
import Tutorials from './components/Tutorials';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen font-sans bg-navy-900 text-text-primary">
      <Navbar />
      
      <main>
        <Hero />
        <Featured />
        <Categories />
        <Tutorials />
        <Newsletter />
      </main>

      <Footer />
    </div>
  );
}

export default App;